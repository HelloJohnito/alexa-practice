var Alexa = require('alexa-sdk');

// Constants
var constants = require('../constants/constants');



var onboardingStateHandlers = Alexa.CreateStateHandler(constants.states.ONBOARDING, {

  'NewSession': function () {
      // this.emit(':ask', "Welcome to Ernie Ball's Jamming Session. What genre of music do you want to play, and in what key? <break time='.5s'/> The options for genres are: blues, rock, and jazz. The options for keys are: a, g, c, d, and f. You can start by saying: play rock in the key of A");

      this.handler.state = constants.states.AUDIO_PLAYER;
      this.emitWithState('LaunchRequest');
      // this.emitWithState('JamIntent');
    },

  'AMAZON.StopIntent': function () {
    // State Automatically Saved with :tell
    this.emit(':tell', 'Goodbye!');
  },

  'AMAZON.CancelIntent': function () {
    // State Automatically Saved with :tell
    this.emit(':tell', 'Goodbye!');
  },

  'SessionEndedRequest': function () {
    // Force State to Save when the user times out
    this.emit(':saveState', true);
  },

  'AMAZON.HelpIntent': function () {
    this.emit(':tellWithLinkAccountCard', 'Please link your account to use this skil. I\'ve sent the details to your alexa app.');
  },

  'Unhandled': function () {
    this.emitWithState('AMAZON.HelpIntent');
  }

});

module.exports = onboardingStateHandlers;
