var musicData = {
  party: [
    {
      'url': "https://s3.amazonaws.com/blackbeltdrinks/Eagle+Eye+Cherry+-+Save+Tonight+(GAMPER+%26+DADONI+Remix).mp3"
    }
  ],

  sad: [
    {
      'url': "https://s3-us-west-2.amazonaws.com/ernieballstaging/music/Medium_Rock_in_C.mp3"
    }
  ]
};

module.exports = musicData;
